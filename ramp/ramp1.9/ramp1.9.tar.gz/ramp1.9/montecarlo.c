/********************************************************************
RAMP Lifetime Reliability Model
Version 1.9

The RAMP software was developed as part of the Reliability-Aware
MicroProcessors research project at the IBM T. J. Watson Research Center
and the University of Illinois at Urbana-Champaign and co-directed by
Prof. Sarita V. Adve, Dr. Pradip Bose, and Dr. Jude A. Rivers. It was
written by Jayanth Srinivasan and Pradeep Ramachandran.

The licensing agreement for RAMP is still under deliberation. We expect
that RAMP will be distributed as part of the IBM Microarchitecture
Exploration ToolSet (Turandot) under the current licensing agreement for that
toolset. We are considering an open source license for the standalone
version of RAMP, but that remains to be finalized. Until that is done,
this software is available for academic purposes only and is not to be
redistributed.

The software is provided "as is," without warranty of any kind, express
or implied, including but not limited to the warranties of
merchantability, fitness for a particular purpose and noninfringement.
In no event shall the contributors or copyright holders be liable for
any claim, damages or other liability, whether in an action of contract,
tort or otherwise, arising from, out of or in connection with the
software or the use or other dealings with the software.

If you are using RAMP or an updated version, please cite the following paper:

J. Srinivasan, S. V. Adve, P. Bose, J. A. Rivers, "Exploiting Structural
Duplication for Lifetime Reliability Enhancement," In Proceedings of the
32nd International Symposium on Computer Architecture, June 2005.

 ********************************************************************/

/* 
 * This code was developed by Jayanth Srinivasan
 * */

/* montecarlo.c: Monte-Carlo simulation for RAMP with MIN-MAX code for series-parallel failure
 * analysis*/


/* This file is used to calculate MTTF of series-parallel failure systems using
 * lognormal failure distributions. Details of the exact modeling methodology
 * can be found in:
 *
 * "Exploiting Structural Duplication for Lifetime Reliability Enhancement", J.
 * Srinivasan, S. V. Adve, P. Bose, J. A. Rivers, In the Proceedings of the 32nd
 * International Symposium on Computer Architecture (ISCA-2005), June 2005. */

/* The command line for using this file is 
 *
 * ./montecarlo FITFILE
 *
 * where FITFILE is obtained from RAMP. Generating the FITFILE is shown in
 * runtime.cc. The format of the FIT file is
 * FIT value due to EM for structure 1
 * FIT value due to SM for structure 1
 * FIT value due to TDDB for structure 1
 * FIT value due to TC for structure 1
 * FIT value due to NBTI for structure 1
 * FIT value due to EM for structure 2 ...
 *
 * years */

#include <stdio.h> 
#include <math.h> 
#include <stdlib.h> 
#include <time.h>
#include <string.h>

#define min(X, Y)  ((X) < (Y) ? (X) : (Y)) 
#define max(X, Y)  ((X) > (Y) ? (X) : (Y))

#define NO_STRUCTURES		10	
#define NO_FAILURE_MECHS	5	// EM, SM, TDDB, TC, NBTI

				       // Failure models
#define EM	0
#define SM	1
#define TDDB	2
#define	TC	3
#define NBTI	4

/* Global Variable initalization */
float expected_mttf[NO_FAILURE_MECHS][NO_STRUCTURES] ;
float fits[NO_FAILURE_MECHS][NO_STRUCTURES] ;

int main(int argc,char *argv[])
{
	int fail_count, structure_count;
	int runs;
	float lognorm_lifetime[NO_FAILURE_MECHS][NO_STRUCTURES] ;
	float structure_lifetime[NO_STRUCTURES];
	float totallife, mttftotal = 0.0, finalmttf;
	float SIGMA =  0.5 ;
	int totalruns=10000000;

	char fitfile[100] ;

	strcpy(fitfile,argv[1]);
	/* Reading of FIT values from FITFILE. The read_fits function can be found after
	 * main() */
	read_fits(fitfile);

	srand((unsigned)time(NULL));

	/* This is the main Monte-Carlo simulation loop.*/

	for (runs=0; runs<totalruns; runs++) {
		/* Random lifetimes are generated for each structure and failure mechanism based
		 * on the structure and failure mechanism's MTTF. */
		for (fail_count=0;fail_count<NO_FAILURE_MECHS;fail_count++) {
			for (structure_count=0;structure_count<NO_STRUCTURES;structure_count++) {

				float r1, r2, mean, z, n ;
				
				/* The MTTF value of each structure due to each failure mechanism depends on its
				 * FIT value. 1 FIT represents one failure in 10E9 operating hours. Therefore, a
				 * FIT value of 3805.17503 gives an MTTF of 30 years. */
				if( runs == 0 ) {  	// Only the first time, we calculate tehe expected mttf
					expected_mttf[fail_count][structure_count] = (30 * 3805.17503)/fits[fail_count][structure_count] ;
				}

				r1= (float)rand()/RAND_MAX;
				r2 = (float)rand()/RAND_MAX ;

				/* Now, using box-muller transform, we generate a lognormal distribution
				 */
				mean = log(expected_mttf[fail_count][structure_count]) - SIGMA * SIGMA / 2 ;	// Mean of thenormal distribution
				z = sqrt( -2 * log(r1) ) * sin( 2 * M_PI * r2 ) ;	// Standard noormal
				n = mean + z * SIGMA ;					// Scaled normal
				lognorm_lifetime[fail_count][structure_count] = exp(n) ;// Exponentaite to make lognormal
			}
		}

		/* In order to calculate lifetime for a series-parallel failure system, we use
		 * the MIN-MAX method. Simply put, the lifetime of two structures in series is
		 * the minimum of the lifetime of the individual structures. Similarly, the
		 * lifetime of two structures in parallel is the maximum of the lifetime of the
		 * individual structures. */

		/* Within each structure, the individual failure mechanisms act like a series
		 * failure system. That is, the first failure due to any mechanism will cause
		 * the entire structure to fail. Structure_lifetime gives the lifetime of the
		 * structure due to all mechanisms.*/

		for (structure_count=0;structure_count<NO_STRUCTURES;structure_count++) {
			structure_lifetime[structure_count]=
				min(
					min(
						min(
							min( lognorm_lifetime[EM][structure_count], lognorm_lifetime[SM][structure_count]),
							lognorm_lifetime[TDDB][structure_count]),
						lognorm_lifetime[TC][structure_count]),
					lognorm_lifetime[NBTI][structure_count]);
		}

		/* The next step is to calculate the lifetime of the entire series-parallel
		 * Here, we assume that structures 0 and 1 are in parallel, and so are 2 and 3.
		 * In other words, structures 0 and 2 are duplicated, while the others are not.
		 */

		totallife = min( 
				min( 
					min( 
						min( 
							min( 
								min(
									min(
										max( structure_lifetime[0], structure_lifetime[1] ),
										max( structure_lifetime[2], structure_lifetime[3] ) ),
									structure_lifetime[4] ), 
								structure_lifetime[5] ), 
							structure_lifetime[6] ), 
						structure_lifetime[7] ), 
					structure_lifetime[8] ),
			  structure_lifetime[9] ) ;
		
		mttftotal+=totallife;

	} /* end Monte-Carlo iterations */

	finalmttf=mttftotal/totalruns; /* The average across all iterations of the
					  Monte-Carlo algorithm give the final MTTF of the processor. */ 

	printf("Lognormal MTTF of the series-parallel processor with FIT values from %s is %f\n",fitfile,finalmttf);

} /* end main()*/


int read_fits(char *fitfile)
{
	int tempvar=0;
	int structure_count=0; /* Variable to keep track of structures */
	int fail_count=0; 	   /* Variable to keep track of failure mechs */
	float tempfit=0.0;
	char s[100];

	FILE *fp = fopen(fitfile,"r");	/* Open file containing FIT values from
					   RAMP */
	if(!fp)
	{
		printf("ERROR - Can't open FIT file %s \n",fitfile);
	}

	for (fail_count=0;fail_count<NO_FAILURE_MECHS;fail_count++)
	{
		for (structure_count=0;structure_count<NO_STRUCTURES;structure_count++)
		{
			fgets(s,1000,fp);
			tempvar =   sscanf(s,"%f",&tempfit);
			fits[fail_count][structure_count]=tempfit;
		}
	}

	fclose(fp);
	return 0;
}
