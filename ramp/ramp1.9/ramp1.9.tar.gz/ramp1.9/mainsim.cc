/********************************************************************
RAMP Lifetime Reliability Model
Version 1.9

The RAMP software was developed as part of the Reliability-Aware
MicroProcessors research project at the IBM T. J. Watson Research Center
and the University of Illinois at Urbana-Champaign and co-directed by
Prof. Sarita V. Adve, Dr. Pradip Bose, and Dr. Jude A. Rivers. It was
written by Jayanth Srinivasan and Pradeep Ramachandran.

The licensing agreement for RAMP is still under deliberation. We expect
that RAMP will be distributed as part of the IBM Microarchitecture
Exploration ToolSet (Turandot) under the current licensing agreement for that
toolset. We are considering an open source license for the standalone
version of RAMP, but that remains to be finalized. Until that is done,
this software is available for academic purposes only and is not to be
redistributed.

The software is provided "as is," without warranty of any kind, express
or implied, including but not limited to the warranties of
merchantability, fitness for a particular purpose and noninfringement.
In no event shall the contributors or copyright holders be liable for
any claim, damages or other liability, whether in an action of contract,
tort or otherwise, arising from, out of or in connection with the
software or the use or other dealings with the software.

If you are using RAMP or an updated version, please cite the following paper:

J. Srinivasan, S. V. Adve, P. Bose, J. A. Rivers, "Exploiting Structural
Duplication for Lifetime Reliability Enhancement," In Proceedings of the
32nd International Symposium on Computer Architecture, June 2005.

 ********************************************************************/

/* 
 * This code was developed by Jayanth Srinivasan
 * */


/* Initialization code to be inserted in startup file of performance simulator
 * */


#include "reliability.h"

UnitRel *rel_unit;		/* Class containing all reliability data*/
double total_struct_area;	/* Total processor die area*/
extern double total_fits;	/*  Total FITS (1/MTTF) of the entire processor*/
int rel_counter;
long double access_counter;
int unitc;					/* Unit counter*/

total_fits = 0.0;	
total_struct_area=0.0;
access_counter = 0.0; 

/* Reliability objects and memory allocation*/
rel_unit=(UnitRel *)calloc(flp->n_units,sizeof(UnitRel));	

if (!rel_unit)
	fprintf(simerr,"FAILURE DUE TO CALLOC OF RELIABILITY OBJECTS \n");


/* Reliability object initialization for every structure on the processor*/
for (unitc=0;unitc< flp->n_units;unitc++)
{
	rel_unit[unitc].init(flp,unitc);	/* Initialize structures*/
	rel_unit[unitc].fitinit(unitc);		/* Initialize FITS for each structure*/
}
