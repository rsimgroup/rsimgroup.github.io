Authors
=======
Alex Li (manlapli@uiuc.edu)
Ruchira Sasanka (sasanka@uiuc.edu)

Tachyon Ray Tracer
==================

The Tachyon ray tracer is a multi-threaded software, ALPbench includes
it for the evaluation of TLP and ILP. However, no modifications are
done on the software.

The software can be can be downloaded at
http://jedi.ks.uiuc.edu/~johns/raytracer/
