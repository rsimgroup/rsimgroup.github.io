/*
 *  GaborPlacement.h
 *  QTGaborGui
 *
 *  Created by David  Bolme on Tue Jul 30 2002.
 *  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef GABOR_PLACEMENT_INCLUDED
#define GABOR_PLACEMENT_INCLUDED


#endif

