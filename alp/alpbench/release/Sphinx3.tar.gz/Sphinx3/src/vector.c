/*
 * 
 * This file is part of the ALPBench Benchmark Suite Version 1.0
 * 
 * Copyright (c) 2005 The Board of Trustees of the University of Illinois
 * 
 * All rights reserved.
 * 
 * ALPBench is a derivative of several codes, and restricted by licenses
 * for those codes, as indicated in the source files and the ALPBench
 * license at http://www.cs.uiuc.edu/alp/alpbench/alpbench-license.html
 * 
 * The multithreading and SSE2 modifications for SpeechRec, FaceRec,
 * MPEGenc, and MPEGdec were done by Man-Lap (Alex) Li and Ruchira
 * Sasanka as part of the ALP research project at the University of
 * Illinois at Urbana-Champaign (http://www.cs.uiuc.edu/alp/), directed
 * by Prof. Sarita V. Adve, Dr. Yen-Kuang Chen, and Dr. Eric Debes.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal with the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimers.
 * 
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimers in the documentation and/or other materials provided
 *       with the distribution.
 * 
 *     * Neither the names of Professor Sarita Adve's research group, the
 *       University of Illinois at Urbana-Champaign, nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this Software without specific prior written permission.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTRIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH THE
 * SOFTWARE.
 * 
 */


/* ====================================================================
 * Copyright (c) 1999-2001 Carnegie Mellon University.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * This work was supported in part by funding from the Defense Advanced 
 * Research Projects Agency and the National Science Foundation of the 
 * United States of America, and the CMU Sphinx Speech Consortium.
 *
 * THIS SOFTWARE IS PROVIDED BY CARNEGIE MELLON UNIVERSITY ``AS IS'' AND 
 * ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL CARNEGIE MELLON UNIVERSITY
 * NOR ITS EMPLOYEES BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ====================================================================
 *
 */
/*
 * vector.c
 *
 * **********************************************
 * CMU ARPA Speech Project
 *
 * Copyright (c) 1997 Carnegie Mellon University.
 * ALL RIGHTS RESERVED.
 * **********************************************
 * 
 * HISTORY
 * 
 * 10-Mar-1999	M K Ravishankar (rkm@cs.cmu.edu) at Carnegie Mellon University.
 * 		Added vector_accum(), vector_vqlabel(), and vector_vqgen().
 * 
 * 09-Mar-1999	M K Ravishankar (rkm@cs.cmu.edu) at Carnegie Mellon University.
 * 		Added vector_is_zero(), vector_cmp(), and vector_dist_eucl().
 * 		Changed the name vector_dist_eval to vector_dist_maha.
 * 
 * 07-Oct-98	M K Ravishankar (rkm@cs.cmu.edu) at Carnegie Mellon University.
 * 		Added distance computation related functions.
 * 
 * 12-Nov-95	M K Ravishankar (rkm@cs.cmu.edu) at Carnegie Mellon University.
 * 		Copied from Eric Thayer.
 */

#include "vector.h"
#include "logs3.h"
#include "s3types.h"

#if (WIN32) 
/* RAH #include <random.h> */
#include <time.h>		/* RAH */
#endif

float64 vector_sum_norm (float32 *vec, int32 len)
{
    float64 sum, f;
    int32 i;
    
    sum = 0.0;
    for (i = 0; i < len; i++)
	sum += vec[i];

    if (sum != 0.0) {
	f = 1.0 / sum;
	for (i = 0; i < len; i++)
	  /*	  vec[i] *=  f;		*/  /*  */
	  /* The compiler was complaining about the above line, to make sure we don't lose accuracy, use this  */
	  vec[i] = (float32) ((float64) vec[i] * (float64)  f);		
    }
    
    return sum;
}


void vector_floor (float32 *vec, int32 len, float64 flr)
{
    int32 i;

    for (i = 0; i < len; i++)
	if (vec[i] < flr)
	    vec[i] = (float32)flr;
}


void vector_nz_floor (float32 *vec, int32 len, float64 flr)
{
    int32 i;

    for (i = 0; i < len; i++)
	if ((vec[i] != 0.0) && (vec[i] < flr))
	    vec[i] = (float32)flr;
}


void vector_print(FILE *fp, vector_t v, int32 dim)
{
    int32 i;
    
    for (i = 0; i < dim; i++)
	fprintf (fp, " %11.4e", v[i]);
    fprintf (fp, "\n");
    fflush (fp);
}


int32 vector_is_zero (float32 *vec, int32 len)
{
    int32 i;
    
    for (i = 0; (i < len) && (vec[i] == 0.0); i++);
    return (i == len);	/* TRUE iff all mean values are 0.0 */
}


int32 vector_maxcomp_int32 (int32 *val, int32 len)
{
    int32 i, bi;
    
    bi = 0;
    for (i = 1; i < len; i++) {
	if (val[i] > val[bi])
	    bi = i;
    }
    return bi;
}


int32 vector_mincomp_int32 (int32 *val, int32 len)
{
    int32 i, bi;
    
    bi = 0;
    for (i = 1; i < len; i++) {
	if (val[i] < val[bi])
	    bi = i;
    }
    return bi;
}


int32 vector_maxcomp_float32 (float32 *val, int32 len)
{
    int32 i, bi;
    
    bi = 0;
    for (i = 1; i < len; i++) {
	if (val[i] > val[bi])
	    bi = i;
    }
    return bi;
}


int32 vector_mincomp_float32 (float32 *val, int32 len)
{
    int32 i, bi;
    
    bi = 0;
    for (i = 1; i < len; i++) {
	if (val[i] < val[bi])
	    bi = i;
    }
    return bi;
}


void vector_accum (float32 *dst, float32 *src, int32 len)
{
    int32 i;
    
    for (i = 0; i < len; i++)
	dst[i] += src[i];
}


int32 vector_cmp (float32 *v1, float32 *v2, int32 len)
{
    int32 i;
    
    for (i = 0; i < len; i++) {
	if (v1[i] < v2[i])
	    return -1;
	if (v1[i] > v2[i])
	    return 1;
    }
    
    return 0;
}


int32 vector_mean (float32 *mean, float32 **data, int32 n_vec, int32 n_dim)
{
    int32 i, j;
    float64 f;
    
    assert ((n_vec > 0) && (n_dim > 0));
    
    for (i = 0; i < n_dim; i++)
	mean[i] = 0.0;
    
    for (i = 0; i < n_vec; i++) {
	for (j = 0; j < n_dim; j++)
	    mean[j] += data[i][j];
    }
    
    f = 1.0/(float64)n_vec;
    for (i = 0; i < n_dim; i++)
	mean[i] *= (float32)f;
    
    return 0;
}


float64 vector_dist_eucl (float32 *v1, float32 *v2, int32 len)
{
    float64 d;
    int32 i;
    
    d = 0.0;
    for (i = 0; i < len; i++)
	d += (v1[i] - v2[i]) * (v1[i] - v2[i]);
    
    return d;
}


float64 vector_maha_precomp (float32 *var, int32 len)
{
    float64 det;
    int32 i;
    
    for (det = (float64)0.0, i = 0; i < len; i++) {	/* log(1.0/prod(var[i])) */
	det -= (float64) (log(var[i]));
	var[i] = (float32)(1.0 / (var[i] * 2.0));
    }
    det -= log(2.0 * PI) * len;
    
    return (det * 0.5);	/* sqrt */
}


float64 vector_dist_maha (float32 *vec, float32 *mean, float32 *varinv, float64 loginvdet,
			  int32 len)
{
    float64 dist, diff;
    int32 i;
    
    dist = loginvdet;
    for (i = 0; i < len; i++) {
	diff = (vec[i] - mean[i]);
	dist -= diff * diff * varinv[i];
    }
    
    return dist;
}


int32 vector_vqlabel (float32 *vec, float32 **mean, int32 rows, int32 cols, float64 *sqerr)
{
    int32 i, besti;
    float64 d, bestd;
    
    assert ((rows > 0) && (cols > 0));
    
    bestd = vector_dist_eucl (mean[0], vec, cols);
    besti = 0;
    
    for (i = 1; i < rows; i++) {
	d = vector_dist_eucl (mean[i], vec, cols);
	if (bestd > d) {
	    bestd = d;
	    besti = i;
	}
    }
    
    if (sqerr)
	*sqerr = bestd;
    
    return besti;
}


float64 vector_vqgen (float32 **data, int32 rows, int32 cols, int32 vqrows,
		      float64 epsilon, int32 maxiter,
		      float32 **mean, int32 *map)
{
    int32 i, j, r, it;
    static uint32 seed = 1;
    float64 sqerr, prev_sqerr=0, t;
    bitvec_t sel;
    int32 *count;
    float32 *gmean;
    ptmr_t tm;
    
    assert ((rows >= vqrows) && (maxiter >= 0) && (epsilon > 0.0));
    
    sel = bitvec_alloc (rows);
    
    ptmr_init (&tm);
    ptmr_start (&tm);
    
    /* Pick a random initial set of centroids */
#ifndef WIN32			/* RAH */
    srandom (seed);
    seed ^= random();
#else  /* RAH */
      srand ((unsigned) time(NULL)); /* RAH */
#endif
    for (i = 0; i < vqrows; i++) {
	/* Find r = a random, previously unselected row from the input */

#ifndef WIN32			/* RAH */
	r = (random() & (int32)0x7fffffff) % rows;
#else  /* RAH */
	r = (rand() & (int32)0x7fffffff) % rows; /* RAH */
#endif /* RAH */
	while (bitvec_is_set (sel, r)) {	/* BUG: possible infinite loop!! */
	    if (++r >= rows)
		r = 0;
	}
	bitvec_set (sel, r);
	
	memcpy ((void *)(mean[i]), (void *)(data[r]), cols * sizeof(float32));
	/* BUG: What if two randomly selected rows are identical in content?? */
    }
    bitvec_free (sel);
    
    count = (int32 *) ckd_calloc (vqrows, sizeof(int32));
    
    /* In k-means, unmapped means in any iteration are a problem.  Replace them with gmean */
    gmean = (float32 *) ckd_calloc (cols, sizeof(float32));
    vector_mean (gmean, mean, vqrows, cols);

    for (it = 0;; it++) {		/* Iterations of k-means algorithm */
	/* Find the current data->mean mappings (labels) */
	sqerr = 0.0;
	for (i = 0; i < rows; i++) {
	    map[i] = vector_vqlabel (data[i], mean, vqrows, cols, &t);
	    sqerr += t;
	}
	ptmr_stop(&tm);
	
	if (it == 0)
	    E_INFO("Iter %4d: %.1fs CPU; sqerr= %e\n", it, tm.t_cpu, sqerr);
	else
	    E_INFO("Iter %4d: %.1fs CPU; sqerr= %e; delta= %e\n",
		   it, tm.t_cpu, sqerr, (prev_sqerr-sqerr)/prev_sqerr);
	
	/* Check if exit condition satisfied */
	if ((sqerr == 0.0) || (it >= maxiter-1) ||
	    ((it > 0) && ( ((prev_sqerr - sqerr) / prev_sqerr) < epsilon )) )
	    break;
	prev_sqerr = sqerr;
	
	ptmr_start(&tm);
	
	/* Update (reestimate) means */
	for (i = 0; i < vqrows; i++) {
	    for (j = 0; j < cols; j++)
		mean[i][j] = 0.0;
	    count[i] = 0;
	}
	for (i = 0; i < rows; i++) {
	    vector_accum (mean[map[i]], data[i], cols);
	    count[map[i]]++;
	}
	for (i = 0; i < vqrows; i++) {
	    if (count[i] > 1) {
		t = 1.0 / (float64)(count[i]);
		for (j = 0; j < cols; j++)
		  /*		  mean[i][j] *= t; */ /* RAH, compiler was complaining about this,  */
		  mean[i][j] = (float32) ((float64) mean[i][j] * (float64) t); /*  */
	    } else if (count[i] == 0) {
		E_ERROR("Iter %d: mean[%d] unmapped\n", it, i);
		memcpy (mean[i], gmean, cols * sizeof(float32));
	    }
	}
    }
    
    ckd_free (count);
    ckd_free (gmean);
    
    return sqerr;
}


float64 vector_pdf_entropy (float32 *p, int32 len)
{
    float64 sum;
    int32 i;
    
    sum = 0.0;
#pragma novector
    for (i = 0; i < len; i++) {
	if (p[i] > 0.0)
	    sum -= p[i] * log(p[i]);
    }
    sum /= log(2.0);
    
    return sum;
}


float64 vector_pdf_cross_entropy (float32 *p1, float32 *p2, int32 len)
{
    float64 sum;
    int32 i;
    
    sum = 0.0;
    for (i = 0; i < len; i++) {
	if (p2[i] > 0.0)
	    sum -= p1[i] * log(p2[i]);
    }
    sum /= log(2.0);
    
    return sum;
}

void vector_gautbl_alloc (vector_gautbl_t *gautbl, int32 n_gau, int32 veclen)
{
  int32 tmp;
    gautbl->n_gau = n_gau;
    gautbl->veclen = veclen;
#if 1
    tmp =(veclen%4)? (veclen+4-(veclen%4)):veclen;
    gautbl->mean = (float32 **) ckd_calloc_2da (n_gau, tmp, sizeof(float32));
    gautbl->var = (float32 **) ckd_calloc_2da (n_gau, tmp, sizeof(float32));
    /*printf("n_gau %d tmp %d %p %p\n",n_gau,tmp, gautbl->mean, gautbl->var);*/
#else
    gautbl->mean = (float32 **) ckd_calloc_2d (n_gau, veclen, sizeof(float32));
    gautbl->var = (float32 **) ckd_calloc_2d (n_gau, veclen, sizeof(float32));
#endif
    gautbl->lrd = (float32 *) ckd_calloc (n_gau, sizeof(float32));
    gautbl->distfloor = logs3_to_log (S3_LOGPROB_ZERO);
}


void vector_gautbl_free (vector_gautbl_t *gautbl)
{
    ckd_free_2da ((void **) gautbl->mean);
    ckd_free_2da ((void **) gautbl->var);
    ckd_free ((void *) gautbl->lrd);
}


void vector_gautbl_var_floor (vector_gautbl_t *gautbl, float64 floor)
{
    int32 g;
    
    for (g = 0; g < gautbl->n_gau; g++)
	vector_floor (gautbl->var[g], gautbl->veclen, floor);
}


void vector_gautbl_maha_precomp (vector_gautbl_t *gautbl)
{
    int32 g;
    
    for (g = 0; g < gautbl->n_gau; g++)
	gautbl->lrd[g] = (float32) vector_maha_precomp (gautbl->var[g], gautbl->veclen);
}





#if 0 /* original code */

void vector_gautbl_eval_logs3 (vector_gautbl_t *gautbl,
			       int32 offset,
			       int32 count,
			       float32 *x,
			       int32 *score)
{
    int32 i, r;
    float64 f;
    int32 end, veclen;
    float32 *m1, *m2, *v1, *v2;
    float64 dval1, dval2, diff1, diff2;
    
    f = log_to_logs3_factor();
    
    /* Interleave evaluation of two vectors at a time for speed on pipelined machines */
    end = offset + count;
    veclen = gautbl->veclen;
    
    for (r = offset; r < end-1; r += 2) {
	m1 = gautbl->mean[r];
	m2 = gautbl->mean[r+1];
	v1 = gautbl->var[r];
	v2 = gautbl->var[r+1];
	dval1 = gautbl->lrd[r];
	dval2 = gautbl->lrd[r+1];

	for (i = 0; i < veclen; i++) {
	    diff1 = x[i] - m1[i];
	    dval1 -= diff1 * diff1 * v1[i];
	    diff2 = x[i] - m2[i];
	    dval2 -= diff2 * diff2 * v2[i];
	}
	
	if (dval1 < gautbl->distfloor)
	    dval1 = gautbl->distfloor;
	if (dval2 < gautbl->distfloor)
	    dval2 = gautbl->distfloor;

	score[r] = (int32)(f * dval1);
	score[r+1] = (int32)(f * dval2);
    }
    
    if (r < end) {
	m1 = gautbl->mean[r];
	v1 = gautbl->var[r];
	dval1 = gautbl->lrd[r];
	
	for (i = 0; i < veclen; i++) {
	    diff1 = x[i] - m1[i];
	    dval1 -= diff1 * diff1 * v1[i];
	}
	
	if (dval1 < gautbl->distfloor)
	    dval1 = gautbl->distfloor;

	score[r] = (int32)(f * dval1);
    }
}


#else /* new unrolled / SIMD code */

#ifdef SSE2 /*SIMD code */


float64 vector_gautbl_eval_logs3_inner(vector_gautbl_t *gautbl,
				       const int32 r, const float32 *x) { 

  __declspec(align(16)) static const float32 zero[4] = {0.0, 0.0, 0.0, 0.0};

  float32 *m1, *v1, *xp=x, *m1p, *v1p, tmp=0.0, *tp, vdiff;
  float64 dval1,diff;
  int32 veclen, i;

  m1p = m1 = gautbl->mean[r];
  v1p = v1 = gautbl->var[r];
  dval1 = gautbl->lrd[r];
  veclen = gautbl->veclen;
   
  i = veclen>>2;
   
   __asm
    {
      mov    ecx, [i]       ;
      movups xmm2, [zero]        ;
      mov    eax, [x]          ;
      mov    edx, [m1]         ;
      mov    ebx, [v1]         ;

    vecg_eloop:
      movups xmm0, [eax]        ; /*load 4 floats from x */
      movups xmm1, [edx]        ; /*load 4 floats from m1*/
      subps  xmm0, xmm1        ; /*xmm0 has x-m  */
      movups xmm1, [ebx]        ; /*load 4 floats from v1 */
      mulps  xmm0, xmm0        ; /*xmm0 has (x-m)^2  */
      mulps  xmm0, xmm1        ; /*xmm0 has (x-m)^2*v1 */
      addps  xmm2, xmm0        ; /*partial sum at xmm2*/
      add    eax, 16       ;
      add    ebx, 16       ;
      add    edx, 16       ;
      sub     ecx, 1        ;
      cmp     ecx, 0        ;
      jnz     vecg_eloop    ;

      pshufd xmm1, xmm2, 14    ; /* reduction */
      addps  xmm2, xmm1        ;
      pshufd xmm1, xmm2, 1     ;
      addss  xmm2, xmm1        ;
      movss  [tmp], xmm2        ;
    } 
  i<<=2;
  
  dval1 -= tmp;
  
#ifdef LOGS3_NO_LOOP   /*13 elements assumed, undef to unassume */
  diff = x[i] - m1[i];
  dval1 -= diff * diff * v1[i];
#else
  for (;i<veclen; i++) {
    diff = x[i] - m1[i];
    dval1 -= diff * diff * v1[i];
  };
#endif

  return dval1;
}

#else /*non-SIMD code */


float64 vector_gautbl_eval_logs3_inner(vector_gautbl_t *gautbl,
				       const int32 r, const float32 *x) { 

  float32 *m1, *v1;
  float64 dval1, vdiff[4], vdval[4]; 
  int32 veclen, i;

  m1 = gautbl->mean[r];
  v1 = gautbl->var[r];
  dval1 = gautbl->lrd[r];
  veclen = gautbl->veclen;
  
  /* clears vdval, reset v0 and start from the next record of m1 and v1 */
  vdval[0] = vdval[1] = vdval[2] = vdval[3] = 0.0;

#if 1
  veclen = (veclen%4)?veclen+4-(veclen%4):veclen;
  for (i = 0; i < veclen; i+=4) {
    /*_mm_prefetch(&m1[i]+16,_MM_HINT_NTA);
      _mm_prefetch(&v1[i]+16,_MM_HINT_NTA);*/

    vdiff[0] = x[i] - m1[i];
    vdval[0] += vdiff[0] * vdiff[0] * v1[i];
    
    vdiff[1] = x[i+1] - m1[i+1];
    vdval[1] += vdiff[1] * vdiff[1] * v1[i+1];
    
    vdiff[2] = x[i+2] - m1[i+2];
    vdval[2] += vdiff[2] * vdiff[2] * v1[i+2];
    
    vdiff[3] = x[i+3] - m1[i+3];
    vdval[3] += vdiff[3] * vdiff[3] * v1[i+3];
    
  }
#else
#pragma novector
  for (i = 0; i < veclen-3; i+=4) {

    vdiff[0] = x[i] - m1[i];
    vdval[0] += vdiff[0] * vdiff[0] * v1[i];
    
    vdiff[1] = x[i+1] - m1[i+1];
    vdval[1] += vdiff[1] * vdiff[1] * v1[i+1];
    
    vdiff[2] = x[i+2] - m1[i+2];
    vdval[2] += vdiff[2] * vdiff[2] * v1[i+2];
    
    vdiff[3] = x[i+3] - m1[i+3];
    vdval[3] += vdiff[3] * vdiff[3] * v1[i+3];
    
  }

  
#ifdef LOGS3_NO_LOOP

  vdiff[0] = x[i] - m1[i];
  vdval[0] += vdiff[0] * vdiff[0] * v1[i];

#else /* compiler automatically unroll the following, hence the above */

  for (;i<veclen; i++) {
   vdiff[0] = x[i] - m1[i];
   vdval[0] += vdiff[0] * vdiff[0] * v1[i];
  };

#endif
#endif /*#if 1*/  
  /* do the reduction */

  dval1 -= (vdval[0] + vdval[1] + vdval[2] +vdval[3] );

   /* Original loop
 	for (i = 0; i < veclen; i++) {
	    diff1 = x[i] - m1[i];
	    dval1 -= diff1 * diff1 * v1[i];
	}
  */

  return dval1;
}

#endif /*end unrolled code */


void vector_gautbl_eval_logs3 (vector_gautbl_t *gautbl,
			       int32 offset,
			       int32 count,
			       float32 *x,
			       int32 *score)
{
    int32 i, r;
    float64 f;
    int32 end, veclen;
    float32 *m1, *m2, *v1, *v2;
    float64 dval1, dval2, diff1, diff2;
    
    f = log_to_logs3_factor();
    
    /* Interleave evaluation of two vectors at a time for speed on pipelined machines */
    end = offset + count;
    for (r = offset; r < end; r ++) {

      dval1 =  vector_gautbl_eval_logs3_inner(gautbl, r, x);

      if (dval1 < gautbl->distfloor)
	dval1 = gautbl->distfloor;

      score[r] = (int32)(f * dval1);
    }

}




#endif /* end new unrolled code */

