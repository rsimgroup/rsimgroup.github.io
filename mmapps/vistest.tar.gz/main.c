/* Sample VIS code */
/* Written by Chris Hughes */
/* Simple dot product of 16-bit samples */

#include <stdio.h>
#include "vis_proto.h"
#include "vis_types.h"

/* Sample arrays - numbers will be in Q.15 format.  This means sixteen bit
numbers (hence the short ints) with one of those being a sign bit (this is
automatic with 2's complement notation). The remaining fifteen bits are treated
as binary digits AFTER the decimal point.  In other words, these are signed
numbers in the interval [-1,1).  For example, 1000000000000000 = -1 and
0100000000000000 = 0.5. */

short x[16],y[16];
#define MAXMAGNITUDE 32768

int main(void)
{
  int i,j;
  short sum;

#ifdef VIS
  vis_u8 *sa,*sb;
  vis_d64 *sp,*sp1;
  vis_d64 s0,s1,s00,s10,sd,sd1;
  vis_d64 resultu,resultl;
  union {vis_d64 d64;
    vis_s16 s16[4];} dd;
#endif

  /* Initialize arrays */
  for (i=0;i<16;i++) {
    x[i]=y[i]=(int)(MAXMAGNITUDE*i*0.01);
  }

#ifndef VIS
  /* Q.15 multiply and accumulate loop */
  /* The >>15 is to throw away the lower fifteen bits of the result.  The
     result of the multiplication will have thirty-two bits, the top two of
     which are sign bits (that's why we shift by fifteen instead of sixteen).
     The addition of 1<<15 is for rounding purposes, but is not strictly
     necessary. */
  for (i=0,sum=0;i<16;i++) {
    sum+=((x[i]*y[i])+(1<<14))>>15;
  }
#else
  for (i=0,sum=0;i<4;i++) {
    sa=(vis_u8 *)(&x[4*i]);
    sb=(vis_u8 *)(&y[4*i]);

    /* Get the first four operands into sd */
    sp=(vis_d64 *)vis_alignaddr(sa,0);
    s0=sp[0];
    s1=sp[1];
    sd=vis_faligndata(s0,s1);

    /* Get the second four operands into sd1 */
    sp1=(vis_d64 *)vis_alignaddr(sb,0);
    s00=sp1[0];
    s10=sp1[1];
    sd1=vis_faligndata(s00, s10);
  
    /* Do the multiplication - the VIS multiplications will automatically keep
       only the most significant 16 bits (i.e., it does a >>16 on each
       result. */
    resultu = vis_fmul8sux16(sd,sd1);
    resultl = vis_fmul8ulx16(sd,sd1);
    dd.d64 = vis_fpadd16(resultu, resultl);

    /* Sum the four results up - the shift is necessary since the VIS shift is
       by sixteen instead of fifteen. */
    for (j=0;j<4;j++)
      sum+=dd.s16[j]<<1;
  }
#endif

  printf("Final result is %d (%f)\n",sum,(double)sum/MAXMAGNITUDE);
}
