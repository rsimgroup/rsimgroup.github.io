/* Copyright (C) 1995, 1997, Sun Microsystems, Inc. */

#ifndef VIS_TYPES_H
#define VIS_TYPES_H

#pragma ident	"@(#)vis_types.h	1.1	97/03/06 SMI"

#ifdef	__cplusplus
extern "C" {
#endif

typedef signed char     vis_s8;
typedef unsigned char   vis_u8;
typedef short           vis_s16;
typedef unsigned short  vis_u16;
typedef int		vis_s32;
typedef unsigned int	vis_u32;
typedef float		vis_f32;
typedef double		vis_d64;

typedef void		*vis_ras;

#ifdef	__cplusplus
}
#endif

#endif	/* VIS_TYPES_H */
