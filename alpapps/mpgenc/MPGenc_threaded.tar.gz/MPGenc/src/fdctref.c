/* fdctref.c, forward discrete cosine transform, double precision           */

/* Copyright (C) 1996, MPEG Software Simulation Group. All Rights Reserved. */

/*
 * Disclaimer of Warranty
 *
 * These software programs are available to the user without any license fee or
 * royalty on an "as is" basis.  The MPEG Software Simulation Group disclaims
 * any and all warranties, whether express, implied, or statuary, including any
 * implied warranties or merchantability or of fitness for a particular
 * purpose.  In no event shall the copyright-holder be liable for any
 * incidental, punitive, or consequential damages of any kind whatsoever
 * arising from the use of these programs.
 *
 * This disclaimer of warranty extends to the user of these programs and user's
 * customers, employees, agents, transferees, successors, and assigns.
 *
 * The MPEG Software Simulation Group does not represent or warrant that the
 * programs furnished hereunder are free of infringement of any third-party
 * patents.
 *
 * Commercial implementations of MPEG-1 and MPEG-2 video, including shareware,
 * are subject to royalty fees to patent holders.  Many of these patents are
 * general enough such that they are unavoidable regardless of implementation
 * design.
 *
 */

#include <math.h>

#include "config.h"
#include "global.h"

#ifndef PI
# ifdef M_PI
#  define PI M_PI
# else
#  define PI 3.14159265358979323846
# endif
#endif

/* global declarations */
void init_fdct _ANSI_ARGS_((void));
void fdct _ANSI_ARGS_((short *block));

/* private data */
#ifndef INT_DCT
static double c[8][8]; /* transform coefficients */
#endif


void init_fdct()
{
  int i, j;
  double s;

  for (i=0; i<8; i++)
  {
    s = (i==0) ? sqrt(0.125) : 0.5;

    for (j=0; j<8; j++){

#ifdef INT_DCT
      /* scaled with 2^15*/
      c[i][j] = (short) ((s * cos((PI/8.0)*i*(j+0.5)) * 32768) + 0.5); 
      ic[j][i] = c[i][j];
#else
      c[i][j] = s * cos((PI/8.0)*i*(j+0.5));
#endif
    }
      
  }
}



void fdct(block)
short *block;
{

  int i, j, k;
#ifndef INT_DCT
  double s;
  double tmp[64];
#else
  int s;
  short tmp[64];
#endif


  for (i=0; i<8; i++) { 

 
    for (j=0; j<8; j++) { 

#ifdef INT_DCT
      s = 0;
#else
      s = 0.0;
#endif

      for (k=0; k<8; k++)
        s += c[j][k] * block[8*i+k];          /* this is block[i][k] */
#ifdef INT_DCT
      tmp[8*i+j] = s >> 15;                         /* this is block[i][j] */
#else
      tmp[8*i+j] = s;
#endif 

    }  /* for j */
  

  } /* for i */


  for (j=0; j<8; j++) {

    for (i=0; i<8; i++) {

#ifdef INT_DCT
      s = 0;
#else
      s = 0.0;
#endif

      for (k=0; k<8; k++)
        s += c[i][k] * tmp[8*k+j];

#ifdef INT_DCT
      block[8*i+j] =  s >> 15;
#else
      block[8*i+j] = (int)floor(s+0.499999);
#endif


      /*
       * reason for adding 0.499999 instead of 0.5:
       * s is quite often x.5 (at least for i and/or j = 0 or 4)
       * and setting the rounding threshold exactly to 0.5 leads to an
       * extremely high arithmetic implementation dependency of the result;
       * s being between x.5 and x.500001 (which is now incorrectly rounded
       * downwards instead of upwards) is assumed to occur less often
       * (if at all)
       */

    } /* end of i */


  } /* end of j */



}




