/* quantize.c, quantization / inverse quantization                          */

/* Copyright (C) 1996, MPEG Software Simulation Group. All Rights Reserved. */

/*
 * Disclaimer of Warranty
 *
 * These software programs are available to the user without any license fee or
 * royalty on an "as is" basis.  The MPEG Software Simulation Group disclaims
 * any and all warranties, whether express, implied, or statuary, including any
 * implied warranties or merchantability or of fitness for a particular
 * purpose.  In no event shall the copyright-holder be liable for any
 * incidental, punitive, or consequential damages of any kind whatsoever
 * arising from the use of these programs.
 *
 * This disclaimer of warranty extends to the user of these programs and user's
 * customers, employees, agents, transferees, successors, and assigns.
 *
 * The MPEG Software Simulation Group does not represent or warrant that the
 * programs furnished hereunder are free of infringement of any third-party
 * patents.
 *
 * Commercial implementations of MPEG-1 and MPEG-2 video, including shareware,
 * are subject to royalty fees to patent holders.  Many of these patents are
 * general enough such that they are unavoidable regardless of implementation
 * design.
 *
 */

#include <stdio.h>
#include "config.h"
#include "global.h"


extern int QUANT_THRESHOLD;


static void iquant1_intra _ANSI_ARGS_((short *src, short *dst,
  int dc_prec, unsigned char *quant_mat, int mquant));
static void iquant1_non_intra _ANSI_ARGS_((short *src, short *dst,
  unsigned char *quant_mat, int mquant));


#ifdef LTHREAD
void ptquant(start_mbh, end_mbh)
int start_mbh, end_mbh;
{
  int k, mb_type, comp, cbp;

  /* load quantization matirices into v0 and v1, which are used by
     quant_intra, quant_non_intra, iquant_intra, iquant_non_intra.
     At this point, we are loading the matricies for child threads.
  */

  for (k=start_mbh; k<end_mbh; k++) {

      mb_type = mbinfo[k].mb_type;

      /* determine mquant (rate control) */
      /*mbinfo[k].mquant = rc_calc_mquant(k);*/
      mbinfo[k].mquant = 20;

      /* quantize macroblock */
      if (mb_type & MB_INTRA)
      {
	for (comp=0; comp<block_count; comp++) {
	  int ind = k*block_count+comp;
	  
	  quant_intra(blocks[ind],blocks[ind],
                      dc_prec,intra_q,mbinfo[k].mquant);
	}
        mbinfo[k].cbp = cbp = (1<<block_count) - 1;
	
      }
      else
      {
        cbp = 0;
        
	for (comp=0;comp<block_count;comp++) {
	  
	  int ind = k*block_count+comp;
	  
          cbp = (cbp<<1) | quant_non_intra(blocks[ind],blocks[ind],
                                           inter_q, mbinfo[k].mquant);
	}
	
        mbinfo[k].cbp = cbp;
	
      }

  }

}


void ptiquant(start_k, end_k)
int start_k, end_k;
{
  int k, j;


  for (k=start_k; k<end_k; k++) {

      if (mbinfo[k].mb_type & MB_INTRA)
	for (j=0; j<block_count; j++) {

	  int ind = k*block_count+j;

	  iquant_intra(blocks[ind],blocks[ind],
		       dc_prec, intra_q, mbinfo[k].mquant);
	}
      else
	for (j=0;j<block_count;j++) {

	  int ind = k*block_count+j;

	  iquant_non_intra(blocks[ind],blocks[ind],
			   inter_q,mbinfo[k].mquant);
	}

  }

}


#endif

/* Test Model 5 quantization
 *
 * this quantizer has a bias of 1/8 stepsize towards zero
 * (except for the DC coefficient)
 */


int quant_intra(src,dst,dc_prec,quant_mat,mquant)
short *src, *dst;
int dc_prec;
unsigned char *quant_mat;
int mquant;
{
  int i;
  int x, y, d;
  short dst0;

  x = src[0];
  d = 8>>dc_prec; /* intra_dc_mult */
  dst0 = (x>=0) ? (x+(d>>1))/d : -((-x+(d>>1))/d); /* round(x/d) */

  for (i=0; i<64; ) {

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    d = (3*mquant+2)>>2;
    y = (y+d)/(2*mquant); /* (y+0.75*mquant) / (2*mquant) */
    if (y > QUANT_THRESHOLD) y = QUANT_THRESHOLD;
    dst[i] = (x>=0) ? y : -y;
    i++;

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    d = (3*mquant+2)>>2;
    y = (y+d)/(2*mquant); /* (y+0.75*mquant) / (2*mquant) */
    if (y > QUANT_THRESHOLD) y = QUANT_THRESHOLD;
    dst[i] = (x>=0) ? y : -y;
    i++;

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    d = (3*mquant+2)>>2;
    y = (y+d)/(2*mquant); /* (y+0.75*mquant) / (2*mquant) */
    if (y > QUANT_THRESHOLD) y = QUANT_THRESHOLD;
    dst[i] = (x>=0) ? y : -y;
    i++;

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    d = (3*mquant+2)>>2;
    y = (y+d)/(2*mquant); /* (y+0.75*mquant) / (2*mquant) */
    if (y > QUANT_THRESHOLD) y = QUANT_THRESHOLD;
    dst[i] = (x>=0) ? y : -y;
    i++;

  }

  dst[0] = dst0;

  return 1;
}


int quant_non_intra(src,dst,quant_mat,mquant)
short *src, *dst;
unsigned char *quant_mat;
int mquant;
{
  int i;
  int x, y, d;
  int nzflag;

  nzflag = 0;

  for (i=0; i<64; ) {

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    y /= (2*mquant);
    if (y > QUANT_THRESHOLD)  y = QUANT_THRESHOLD;
    if ((dst[i] = (x>=0 ? y : -y)) != 0) nzflag=1;
    i++;

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    y /= (2*mquant);
    if (y > QUANT_THRESHOLD)  y = QUANT_THRESHOLD;
    if ((dst[i] = (x>=0 ? y : -y)) != 0) nzflag=1;
    i++;

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    y /= (2*mquant);
    if (y > QUANT_THRESHOLD)  y = QUANT_THRESHOLD;
    if ((dst[i] = (x>=0 ? y : -y)) != 0) nzflag=1;
    i++;

    x = src[i];
    d = quant_mat[i];
    y = (32*(x>=0 ? x : -x) + (d>>1))/d; /* round(32*x/quant_mat) */
    y /= (2*mquant);
    if (y > QUANT_THRESHOLD)  y = QUANT_THRESHOLD;
    if ((dst[i] = (x>=0 ? y : -y)) != 0) nzflag=1;
    i++;

  }

  return nzflag;
}

/* MPEG-2 inverse quantization */

void iquant_intra(src,dst,dc_prec,quant_mat,mquant)
short *src, *dst;
int dc_prec;
unsigned char *quant_mat;
int mquant;
{
  int i, val, sum, tmp;

  if (mpeg1)
    iquant1_intra(src,dst,dc_prec,quant_mat,mquant);
  else {
    tmp = sum = src[0] << (3-dc_prec);
    
    val = (int)(src[0]*quant_mat[0]*mquant)/16;
    sum -= ((val>2047) ? 2047 : ((val<-2048) ? -2048 : val));
    
    for(i=0; i < 64 ; ) {
      
      val = (int)(src[i]*quant_mat[i]*mquant)/16;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;
      
      val = (int)(src[i]*quant_mat[i]*mquant)/16;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;
      
      val = (int)(src[i]*quant_mat[i]*mquant)/16;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;
      
      val = (int)(src[i]*quant_mat[i]*mquant)/16;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;
      
    }
    
    
    dst[0] = tmp;
    
    /* mismatch control */
    if ((sum&1)==0)
      dst[63]^= 1;
  }
  
     
}


void iquant_non_intra(src,dst,quant_mat,mquant)
short *src, *dst;
unsigned char *quant_mat;
int mquant;
{
  int i, val, sum;
 
  if (mpeg1)
    iquant1_non_intra(src,dst,quant_mat,mquant);
  else {
    
    sum = 0;

    for (i=0; i<64; ) {

      val = src[i];
      if (val!=0)
	val = (int)((2*val+(val>0 ? 1 : -1))*quant_mat[i]*mquant)/32;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;

      val = src[i];
      if (val!=0)
	val = (int)((2*val+(val>0 ? 1 : -1))*quant_mat[i]*mquant)/32;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;

      val = src[i];
      if (val!=0)
	val = (int)((2*val+(val>0 ? 1 : -1))*quant_mat[i]*mquant)/32;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;

      val = src[i];
      if (val!=0)
	val = (int)((2*val+(val>0 ? 1 : -1))*quant_mat[i]*mquant)/32;
      sum+= dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
      i++;

    }

    /* mismatch control */
    if ((sum&1)==0)
      dst[63]^= 1;
  }
}



/******************* Following are Not used anymore -- Ruchira ***********/



/* MPEG-1 inverse quantization */
static void iquant1_intra(src,dst,dc_prec,quant_mat,mquant)
short *src, *dst;
int dc_prec;
unsigned char *quant_mat;
int mquant;
{
  int i, val;

  dst[0] = src[0] << (3-dc_prec);
  for (i=1; i<64; i++)
  {
    val = (int)(src[i]*quant_mat[i]*mquant)/16;

    /* mismatch control */
    if ((val&1)==0 && val!=0)
      val+= (val>0) ? -1 : 1;

    /* saturation */
    dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
  }
}

static void iquant1_non_intra(src,dst,quant_mat,mquant)
short *src, *dst;
unsigned char *quant_mat;
int mquant;
{
  int i, val;

  for (i=0; i<64; i++)
  {
    val = src[i];
    if (val!=0)
    {
      val = (int)((2*val+(val>0 ? 1 : -1))*quant_mat[i]*mquant)/32;

      /* mismatch control */
      if ((val&1)==0 && val!=0)
        val+= (val>0) ? -1 : 1;
    }

    /* saturation */
    dst[i] = (val>2047) ? 2047 : ((val<-2048) ? -2048 : val);
  }
}
